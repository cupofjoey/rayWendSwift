/*:
 #### Beginning Swift Video Tutorial Series - raywenderlich.com
 #### Video 2: Variables
 
 **Note:** If you're seeing this text as comments rather than nicely-rendered text, select Editor\Show Rendered Markup in the Xcode menu.
 */

import UIKit

//: Declare a constant of type Int called myAge and set it to your age.
let age = 30
//: Create a variable called answer and initialize it with the value 0. Increment it by 1. Add 10 to it. Multiply it by 10 and divide by 3. After all of these operations, what’s the answer?
var answer = 0
answer += 1
answer += 10
answer *= 10
answer /= 3
answer
//: Declare two constants a and b of type Double and assign both a value. Calculate the average of a and b and store the result in a constant named average.
let a = 1
let b = 2
let average = (a + b) / 2



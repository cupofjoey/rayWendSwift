//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var hello = "Hi"
hello = "Hello World"

var helloWorldFromBrian = "Hi"
var helloWorldFrombrian = "Hello"

// my comment goes here
/*
 adfa 
 adsfasdfasdf
 
 asdfasdf
 asdfa
 */

var greeting = "Hello"
var name = "Brian"

var completedGreeting = greeting + name

var myNumber = 10.5
let 𝛑 = 3.141
𝛑 * 2


